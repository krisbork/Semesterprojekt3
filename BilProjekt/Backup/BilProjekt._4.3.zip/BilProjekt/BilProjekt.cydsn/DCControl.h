/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

void driveForwards(void);
void driveBackwards(void);
void stopDriving(void);

void decreaseSpeed(void);
void increaseSpeed(void);

/* [] END OF FILE */
