/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdbool.h>
#include "distSensor.h"
#include "DCControl.h"
#include "servoControl.h"

bool driving = false;
int distance = 0;
int initialDist = 0;

int Pin_RPi_Tester = 1;

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    UART_1_Start();
    PWM_DC_Start();
    PWM_Servo_Start();
    UART_1_PutString("Park-a-lot system started\r\n");

    for(;;)
    {
        if(Pin_RPi_Tester == 1)
        {
            //Find p-plads
            distance = 0;
            initialDist = getDistance();
            middlePos();
            CyDelay(2000);
            driveForwards();
            driving = true;
            UART_1_PutString("Driving forwards. Looking for space\r\n");
            
            
            while(driving == true)
            {
                if(getDistance() > (initialDist+4))
                {
                    distance++;
                    CyDelayUs(10);
                }
                else
                {
                    if(distance > 10)
                    {
                        driving = false;
                        stopDriving();
                        UART_1_PutString("Parking space found\r\n");
                        break;
                    }
                    else
                    {
                        distance = 0;
                        UART_1_PutString("Not enough space\r\n");
                    }
                }
            }
            
            CyDelay(1000);
            UART_1_PutString("Initiating parkingsequence\r\n");
            turnWheelsRight();
            UART_1_PutString("Turning wheels right\r\n");
            CyDelay(500);
            driveBackwards();
            UART_1_PutString("Driving backwards\r\n");
            CyDelay(1000);
            stopDriving();
            turnWheelsLeft();
            UART_1_PutString("Turning wheels left\r\n");
            CyDelay(500);
            driveBackwards();
            UART_1_PutString("Driving backwards again\r\n");
            CyDelay(1000);
            stopDriving(); //parking foretaget
            CyDelay(1000);
            middlePos();
            UART_1_PutString("Parking done\r\n");
            
            Pin_RPi_Tester = 0;
            
        }
    }
}


/* [] END OF FILE */
